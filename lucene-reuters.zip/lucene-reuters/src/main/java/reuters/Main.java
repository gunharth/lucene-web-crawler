package reuters;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.*;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexWriterConfig.OpenMode;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

import info.debatty.java.datasets.reuters.*;

import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Main
{

    public static void main(String[] args) throws Exception {
        // We will use reuters news dataset
        Dataset reuters_dataset = new Dataset("reuters21578");
        String indexPath = "index";

        Directory dir = FSDirectory.open(Paths.get(indexPath));

        Analyzer analyzer = new StandardAnalyzer();

        IndexWriterConfig iwc = new IndexWriterConfig(analyzer);
        //iwc.setOpenMode(OpenMode.CREATE_OR_APPEND);
        iwc.setOpenMode(OpenMode.CREATE);

        IndexWriter writer = new IndexWriter(dir, iwc);

        int i = 1;
        // Iterate over news
        for (News news : reuters_dataset) {
            System.out.println("Count " + i);
            System.out.println(news.date);
            System.out.println(news.title);
            System.out.println(news.body);

            // remove ms from string
            String newsDateString = news.date.substring(0,20);//he
            //System.out.println(substrNewsDate);

            // date conversion to yyyyMMdd for lucene range indexing
            // 1 convert to date
            SimpleDateFormat formatter1 = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
            Date newsStringToDate = formatter1.parse(newsDateString);
            //System.out.println(newsStringToDate);
            // convert to yyyyMMdd format
            SimpleDateFormat formatter2 = new SimpleDateFormat("yyyyMMdd");
            String newsDateToLucene = formatter2.format(newsStringToDate);
            //System.out.println(newsDateToLucene);

            Document doc = new Document();
            doc.add(new StringField("date", newsDateToLucene, Field.Store.YES));
            doc.add(new StringField("title", news.title, Field.Store.YES));
            doc.add(new TextField("body", news.body, Field.Store.YES));

            writer.addDocument(doc);
        i++;

        }

        writer.close();

    }
}