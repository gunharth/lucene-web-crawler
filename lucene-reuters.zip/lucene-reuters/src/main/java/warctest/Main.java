package warctest;

import org.netpreserve.jwarc.MediaType;
import org.netpreserve.jwarc.WarcReader;
import org.netpreserve.jwarc.WarcRecord;
import org.netpreserve.jwarc.WarcResponse;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.FileChannel;
import java.nio.file.Paths;
import java.util.zip.GZIPInputStream;

public class Main {

    public static void main(String[] args) throws IOException {
        //String inputWarcFile="input/ClueWeb09_English_Sample.warc";
        // open our gzip input stream
        //GZIPInputStream inputStream =new GZIPInputStream(new FileInputStream(inputWarcFile));

        //InputStream inputStream = new FileInputStream(inputWarcFile);

        // cast to a data input stream
        //DataInputStream inStream=new DataInputStream(inputStream);

        try (WarcReader reader = new WarcReader(FileChannel.open(Paths.get("input/wappen-00000.warc")))) {
            for (WarcRecord record : reader) {
                if (record instanceof WarcResponse && record.contentType().base().equals(MediaType.HTTP)) {
                    WarcResponse response = (WarcResponse) record;
                    System.out.println(response.http().status() + " " + response.target());
                }
            }
        }
    }
}
