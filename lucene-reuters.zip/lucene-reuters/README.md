1. Run WriteIndex.java -> generates the Index from all files in "inputFiles"
2. Run ReadIndex.java -> query

ReadIndex.java is structuring the Index with JSoup